import React from 'react';

export default function App() {
  return (
    <article id="page_root" style={{"width":"400px","height":"500px","display":"flex","flexDirection":"column","justifyContent":"flex-start","alignItems":"stretch","gap":"16px","flexWrap":"nowrap","backgroundColor":"#1A2640","padding":"24px 24px 24px 24px","borderRadius":"12px 12px 12px 12px"}}>
      <h2 id="page_root_c0" style={{"display":"block","color":"#FFFFFF","fontSize":"24px","fontWeight":700}}>
        Pro Plan
      </h2>
      <button id="page_root_c1" style={{"width":"352px","height":"48px","display":"block","backgroundColor":"#3B82F5","borderRadius":"8px 8px 8px 8px"}}>
        <p id="page_root_c1_c0" style={{"display":"block","color":"#FFFFFF","fontSize":"16px","fontWeight":600}}>
          Get Started
        </p>
      </button>
    </article>
  );
}

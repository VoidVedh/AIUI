// AIUI Autonomous Vanilla JS Application Logic
document.addEventListener('DOMContentLoaded', () => {
  console.log('[AIUI] Application mounted successfully.');

  // Interactive buttons ripple and click handlers
  const buttons = document.querySelectorAll('button');
  buttons.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      console.log(`[AIUI] Button '${btn.innerText.trim()}' clicked.`);
    });
  });
});

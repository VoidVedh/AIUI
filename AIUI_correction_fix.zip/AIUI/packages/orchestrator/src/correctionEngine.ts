import { GeneratedProject, GeneratedFile } from "@aiui/core";
import { VisualIssue } from "@aiui/evaluator";

export interface CorrectionResult {
  patchedProject: GeneratedProject;
  appliedModifications: string[];
}

type Severity = "critical" | "high" | "medium" | "low";

/**
 * Maps issue severity to a corrective magnitude in pixels for issue types
 * where the evaluator does not (yet) supply a real numeric target/actual
 * delta (color contrast, aggregate pixel-diff "spacing" issues). This is a
 * documented approximation, not a claim of pixel-exact correction — see
 * the KNOWN LIMITATION note on the class below.
 */
const SEVERITY_MAGNITUDE_PX: Record<Severity, number> = {
  critical: 22,
  high: 14,
  medium: 8,
  low: 4,
};

/** Clamp a correction so a bad/outlier measurement can't produce a huge, destabilizing shift. */
function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export class CorrectionEngine {
  /**
   * Applies corrections derived from the detected VisualIssue[] list.
   *
   * Never relies on hardcoded fixture-specific IDs or static per-iteration
   * selectors — every rule is keyed off real issue data.
   *
   * QUANTITATIVE (uses real target vs. actual pixel data from the evaluator):
   *   - "position": translates the element by the exact measured delta.
   *   - "missing_element": restores visibility and forces the element's
   *     expected explicit size, when known.
   *
   * KNOWN LIMITATION (severity-scaled, not target-exact):
   *   - "color" and "spacing" issues currently reach this engine with only
   *     a severity level and a description string — the evaluator does not
   *     yet extract a per-element target color or a per-region pixel
   *     offset for these types (see packages/evaluator/src/evaluator.ts,
   *     `generateIssues`). Until the evaluator is extended to produce real
   *     target/actual values for these two types, corrections here are
   *     scaled by severity rather than by a measured delta. This is
   *     intentional and documented rather than faked as exact — treat
   *     improving the evaluator's color/spacing measurement as the next
   *     real step if these issue types keep recurring across iterations.
   */
  public static applyTargetedCorrections(
    project: GeneratedProject,
    issues: VisualIssue[],
    iteration: number
  ): CorrectionResult {
    const appliedModifications: string[] = [];
    const updatedFiles: GeneratedFile[] = project.files.map((f) => ({ ...f }));

    const cssFileIndex = updatedFiles.findIndex((f) => f.path.endsWith(".css"));
    let cssContent = cssFileIndex !== -1 ? updatedFiles[cssFileIndex].content : "";

    if (!issues || issues.length === 0) {
      return {
        patchedProject: project,
        appliedModifications: ["No visual issues detected; layout converged"],
      };
    }

    // Process highest-severity issues first so, if a cap is ever introduced,
    // the biggest problems are addressed before minor polish.
    const severityRank: Record<Severity, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    const sortedIssues = [...issues].sort(
      (a, b) => severityRank[a.severity] - severityRank[b.severity]
    );

    const newCssRules: string[] = [];

    for (const issue of sortedIssues) {
      switch (issue.type) {
        case "position": {
          if (!issue.elementId || !issue.target || !issue.actual) break;
          const dx = clamp(Number(issue.target.x) - Number(issue.actual.x), -200, 200);
          const dy = clamp(Number(issue.target.y) - Number(issue.actual.y), -200, 200);
          if (Number.isNaN(dx) || Number.isNaN(dy)) break;

          newCssRules.push(`
/* Position correction: '${issue.elementId}' measured ${issue.description} */
[id="${issue.elementId}"] {
  transform: translate(${dx.toFixed(1)}px, ${dy.toFixed(1)}px) !important;
  box-sizing: border-box !important;
}
`);
          appliedModifications.push(
            `Translated '${issue.elementId}' by (${dx.toFixed(1)}px, ${dy.toFixed(1)}px) to close a real measured ${Math.round(Math.hypot(dx, dy))}px offset (severity: ${issue.severity})`
          );
          break;
        }

        case "missing_element": {
          if (!issue.elementId) break;
          const targetW = typeof issue.target?.width === "number" ? issue.target.width : undefined;
          const targetH = typeof issue.target?.height === "number" ? issue.target.height : undefined;

          newCssRules.push(`
/* Missing-element correction: '${issue.elementId}' — ${issue.description} */
[id="${issue.elementId}"] {
  display: flex !important;
  visibility: visible !important;
  opacity: 1 !important;
  ${targetW ? `min-width: ${targetW}px !important;` : ""}
  ${targetH ? `min-height: ${targetH}px !important;` : ""}
  box-sizing: border-box !important;
}
`);
          appliedModifications.push(
            `Restored visibility for '${issue.elementId}'` +
              (targetW && targetH ? ` and forced expected size ${targetW}×${targetH}px` : "") +
              ` (severity: ${issue.severity})`
          );
          break;
        }

        case "dimension":
        case "overflow": {
          // Not currently emitted by VisualEvaluator.generateIssues, but the
          // VisualIssue schema allows these types — handle them the same
          // quantitative way if/when the evaluator starts producing them,
          // rather than leaving silently dead code.
          if (!issue.elementId) break;
          const targetW = typeof issue.target?.width === "number" ? issue.target.width : undefined;
          const targetH = typeof issue.target?.height === "number" ? issue.target.height : undefined;
          if (!targetW && !targetH) break;

          newCssRules.push(`
/* Dimension correction: '${issue.elementId}' — ${issue.description} */
[id="${issue.elementId}"] {
  ${targetW ? `width: ${targetW}px !important; max-width: ${targetW}px !important;` : ""}
  ${targetH ? `height: ${targetH}px !important;` : ""}
  box-sizing: border-box !important;
}
`);
          appliedModifications.push(
            `Constrained '${issue.elementId}' to measured target size ${targetW ?? "?"}×${targetH ?? "?"}px (severity: ${issue.severity})`
          );
          break;
        }

        case "color": {
          // KNOWN LIMITATION: no per-element target color is available yet
          // (see class doc comment). Scale a global contrast/legibility
          // correction by severity instead of pretending to know an exact
          // target color.
          const magnitude = SEVERITY_MAGNITUDE_PX[issue.severity];
          const contrastBoost = 1 + magnitude / 100; // e.g. high severity -> 1.14
          newCssRules.push(`
/* Color/contrast correction (severity-scaled, no per-element target color available) — ${issue.description} */
body, .aiui-page {
  -webkit-font-smoothing: antialiased !important;
  -moz-osx-font-smoothing: grayscale !important;
  text-rendering: optimizeLegibility !important;
  filter: contrast(${contrastBoost.toFixed(2)}) !important;
}

h1, h2, h3 {
  letter-spacing: -0.02em !important;
}
`);
          appliedModifications.push(
            `Applied severity-scaled contrast correction (×${contrastBoost.toFixed(2)}) for: ${issue.description} — approximate, not target-color-exact (see known limitation)`
          );
          break;
        }

        case "spacing": {
          // KNOWN LIMITATION: same as color — no per-region pixel offset is
          // available for aggregate pixel-diff issues yet, only severity.
          const magnitude = SEVERITY_MAGNITUDE_PX[issue.severity];
          newCssRules.push(`
/* Spacing correction (severity-scaled, no per-region target offset available) — ${issue.description} */
.aiui-container, [id*="container"], [id*="content"] {
  box-sizing: border-box !important;
  gap: ${magnitude}px !important;
}

button, input {
  cursor: pointer !important;
  box-sizing: border-box !important;
  padding: ${Math.round(magnitude * 0.7)}px ${magnitude}px !important;
}
`);
          appliedModifications.push(
            `Applied severity-scaled spacing correction (${magnitude}px) for: ${issue.description} — approximate, not per-region-exact (see known limitation)`
          );
          break;
        }

        default:
          break;
      }
    }

    if (newCssRules.length > 0) {
      cssContent += `\n/* --- Iteration ${iteration} corrections --- */\n` + newCssRules.join("\n");
      if (cssFileIndex !== -1) {
        updatedFiles[cssFileIndex].content = cssContent;
      }
    }

    return {
      patchedProject: {
        ...project,
        files: updatedFiles,
      },
      appliedModifications:
        appliedModifications.length > 0
          ? appliedModifications
          : [`No actionable corrections could be derived for iteration ${iteration}'s issues (missing element IDs or target data)`],
    };
  }
}
